# ===================================================================
# PYARMOR CODE OBFUSCATION EXAMPLE
# ===================================================================
#
# PyArmor obfuscates bytecode

# ===================================================================

# This is the original source file that I will obfuscate

def factorial_for_pyarmor(n):
    """
    Calculate factorial of a number

    Args:
        n (int): The number to calculate factorial for

    Returns:
        int: Factorial of n, or None if n is negative
    """
    # Input validation - negative numbers don't have factorials
    if n < 0:
        return None

    # Base case: 0! = 1
    if n == 0:
        return 1

    # Calculate factorial using iterative approach
    result = 1
    for i in range(1, n + 1):
        result *= i  # Multiply result by each number from 1 to n

    return result


def fibonacci_for_pyarmor(n):
    """
    Generate the nth Fibonacci number - demonstrates PyArmor capabilities

    Args:
        n (int): Position in Fibonacci sequence

    Returns:
        int: The nth Fibonacci number
    """
    # Handle edge cases
    if n <= 0:
        return 0
    elif n == 1:
        return 1

    # Initialize first two Fibonacci numbers
    prev = 0  # F(0) = 0
    current = 1  # F(1) = 1

    # Calculate Fibonacci iteratively to avoid recursion overhead
    for i in range(2, n + 1):
        temp = prev + current  # Next Fibonacci number
        prev = current  # Move previous forward
        current = temp  # Update current

    return current


def prime_checker_for_pyarmor(n):
    """
    Check if a number is prime - additional function for obfuscation

    Args:
        n (int): Number to check for primality

    Returns:
        bool: True if prime, False otherwise
    """
    # Handle edge cases
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False

    # Check odd divisors up to square root of n
    for i in range(3, int(n ** 0.5) + 1, 2):
        if n % i == 0:
            return False

    return True


class MathUtilsForPyarmor:
    """
    A class containing mathematical utilities for PyArmor demonstration
    This shows how PyArmor handles class obfuscation
    """

    def __init__(self):
        """Initialize the math utils class"""
        self.calculation_count = 0

    def power_calculation(self, base, exponent):
        """
        Calculate base raised to the power of exponent

        Args:
            base (float): The base number
            exponent (int): The exponent

        Returns:
            float: Result of base^exponent
        """
        self.calculation_count += 1
        return base ** exponent

    def gcd_calculation(self, a, b):
        """
        Calculate Greatest Common Divisor using Euclidean algorithm

        Args:
            a (int): First number
            b (int): Second number

        Returns:
            int: GCD of a and b
        """
        self.calculation_count += 1

        # Euclidean algorithm
        while b:
            a, b = b, a % b

        return abs(a)

    def get_stats(self):
        """Return calculation statistics"""
        return f"Total calculations performed: {self.calculation_count}"


# ===================================================================
# STEP 3: TEST SECTION
# ===================================================================
# This section tests all functions before and after obfuscation

def run_tests():
    """Run comprehensive tests on all functions"""
    print("=" * 60)
    print("TESTING FUNCTIONS BEFORE/AFTER PYARMOR OBFUSCATION")
    print("=" * 60)

    # Test factorial function
    print("\n1. FACTORIAL FUNCTION TESTS:")
    test_cases = [0, 1, 5, 7, 10]
    for n in test_cases:
        result = factorial_for_pyarmor(n)
        print(f"   factorial_for_pyarmor({n}) = {result}")

    # Test negative factorial
    negative_result = factorial_for_pyarmor(-5)
    print(f"   factorial_for_pyarmor(-5) = {negative_result}")

    # Test Fibonacci function
    print("\n2. FIBONACCI FUNCTION TESTS:")
    fib_cases = [0, 1, 2, 5, 7, 10]
    for n in fib_cases:
        result = fibonacci_for_pyarmor(n)
        print(f"   fibonacci_for_pyarmor({n}) = {result}")

    # Test prime checker
    print("\n3. PRIME CHECKER TESTS:")
    prime_cases = [2, 3, 4, 5, 17, 25, 29]
    for n in prime_cases:
        result = prime_checker_for_pyarmor(n)
        print(f"   prime_checker_for_pyarmor({n}) = {result}")

    # Test class methods
    print("\n4. CLASS METHOD TESTS:")
    math_utils = MathUtilsForPyarmor()

    # Test power calculation
    power_result = math_utils.power_calculation(2, 8)
    print(f"   power_calculation(2, 8) = {power_result}")

    # Test GCD calculation
    gcd_result = math_utils.gcd_calculation(48, 18)
    print(f"   gcd_calculation(48, 18) = {gcd_result}")

    # Show stats
    print(f"   {math_utils.get_stats()}")

    print("\n" + "=" * 60)
    print("ALL TESTS COMPLETED SUCCESSFULLY!")
    print("=" * 60)


# ===================================================================
# STEP 4: MAIN EXECUTION BLOCK
# ===================================================================
# This runs when the script is executed directly

if __name__ == "__main__":
    # Run all tests
    run_tests()

    print("\n" + "=" * 60)
    print("PYARMOR OBFUSCATION READY!")
    print("=" * 60)
    print("Next steps:")
    print("1. Save this code as 'my_functions.py'")
    print("2. Run: pyarmor obfuscate my_functions.py")
    print("3. Check the 'dist' directory for obfuscated files")
    print("4. Test obfuscated code: python dist/my_functions.py")
    print("=" * 60)

# ===================================================================
# PYARMOR COMMAND LINE OPERATIONS
# ===================================================================
"""
STEP 4A: BASIC OBFUSCATION
-------------------------
# Obfuscate a single file
pyarmor obfuscate my_functions.py


STEP 4B: DISTRIBUTION
-------------------
# The obfuscated files will be in the 'dist' directory
"""
