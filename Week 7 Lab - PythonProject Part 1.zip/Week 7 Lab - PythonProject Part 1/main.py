# Week 7 Lab: Zero-Knowledge Proof and Code Obfuscation Assignment


import random
import time
import os

print("=" * 70)
print("WEEK 7 LAB ASSIGNMENT: ZKP SIMULATION & CODE OBFUSCATION")
print("Student: Nika Asatiani")
print("=" * 70)

# PART 1: ZERO-KNOWLEDGE PROOF (ZKP) SIMULATION
print("\nPART 1: Zero-Knowledge Proof Simulation Implementation")
print("-" * 60)


# To simulate the Ali Baba Cave protocol, I will create a function that models
# an honest prover person who knows the secret password and can always respond correctly
def simulate_zkp_honest(trials=20):
    """
    I am implementing this function to demonstrate how a legitimate prover (Alice)
    who knows the password can always succeed in the ZKP protocol.
    This will help me understand why ZKP works for honest participants.
    """
    print(f"\n IMPLEMENTING: Honest Prover Simulation")
    print(f"I will run {trials} trials to show consistent success with knowledge")

    # I will track successful proofs to calculate the success rate
    success_count = 0  # This counter will track how many times Alice succeeds

    # I will iterate through each trial to simulate the protocol multiple times
    for trial in range(1, trials + 1):
        # I will simulate Alice randomly choosing a path (A or B) to enter the cave
        path_entered = random.choice(['A', 'B'])
        # I will simulate Bob randomly challenging Alice to exit from a specific path
        challenge = random.choice(['A', 'B'])

        # I will set this to True because Alice knows the password in this simulation
        knows_password = True

        # I will determine success based on whether Alice knows the password
        if knows_password:
            # Since Alice knows the password, she can always move between paths
            success = True
        else:
            # If she didn't know the password, success would depend on lucky guessing
            success = path_entered == challenge

            # I will increment the counter when Alice successfully responds
        if success:
            success_count += 1

            # I will print each trial's details
        print(
            f"  Trial {trial:2d}: I entered path {path_entered}, Bob challenged {challenge}, Result: {'Success ✓' if success else 'Failed ✗'}")

    # I will calculate and display the success rate to demonstrate the protocol's effectiveness
    success_rate = (success_count / trials) * 100
    print(f"\n MY RESULTS - Honest Prover Analysis:")
    print(f"  I achieved {success_count}/{trials} successful responses")
    print(f"  My success rate: {success_rate:.1f}% (Expected: 100% with password)")
    return success_count, success_rate


# To demonstrate the security aspect, I will create a function that simulates
# a malicious attacker who doesn't know the password and must guess
def simulate_zkp_malicious(trials=20):
    """
    I am implementing this function to show how an attacker without the password
    can only succeed through random luck, demonstrating the protocol's security.
    This will help me understand why ZKP is secure against fraudulent provers.
    """
    print(f"\n IMPLEMENTING: Malicious Prover Simulation")
    print(f"I will run {trials} trials to show limited success without knowledge")

    # I will track lucky guesses to show the attacker's limitations
    success_count = 0

    # I will simulate each attempt by the malicious prover
    for trial in range(1, trials + 1):
        # I will simulate the attacker randomly choosing a path (no strategic advantage)
        path_entered = random.choice(['A', 'B'])
        # I will simulate Bob's random challenge (same as with honest prover)
        challenge = random.choice(['A', 'B'])

        # I will set this to False because the attacker doesn't know the password
        knows_password = False

        # I will determine success based on knowledge (or lack thereof)
        if knows_password:
            # This branch won't execute since the attacker doesn't know the password
            success = True
        else:
            # I will check if the attacker's random choice matches Bob's challenge
            success = path_entered == challenge

            # I will count successful guesses to analyze the attack success rate
        if success:
            success_count += 1

            # I will display each trial to show the randomness of attacker success
        print(
            f"  Trial {trial:2d}: I guessed path {path_entered}, Bob challenged {challenge}, Result: {'Lucky ✓' if success else 'Failed ✗'}")

    # I will calculate the success rate to demonstrate limited attack effectiveness
    success_rate = (success_count / trials) * 100
    print(f"\n MY RESULTS - Malicious Prover Analysis:")
    print(f"  I achieved {success_count}/{trials} successful guesses")
    print(f"  My success rate: {success_rate:.1f}% (Expected: ~50% due to random chance)")
    print(f"  Theoretical expectation: 50.0% (pure guessing)")
    return success_count, success_rate


# To analyze the protocol's security mathematically, I will create a function
# that calculates the probability of successful attacks over multiple rounds
def calculate_security_analysis(trials=20):
    """
    I am implementing this function to mathematically analyze the security
    of the ZKP protocol and show why multiple rounds provide exponential security.
    This will help me understand the mathematical foundation of ZKP security.
    """
    print(f"\n🔍 IMPLEMENTING: Mathematical Security Analysis")
    print("-" * 45)

    # I will calculate the theoretical probabilities to understand the math behind ZKP
    prob_single_success = 0.5  # 50% chance of correct guess in one trial
    prob_all_success = prob_single_success ** trials  # Probability of succeeding in ALL trials

    # I will display the mathematical analysis to show exponential security improvement
    print(f"I calculated the following probabilities for malicious prover success:")
    print(f"  • Single trial success: {prob_single_success:.3f} ({prob_single_success * 100:.1f}%)")
    print(f"  • All {trials} trials success: {prob_all_success:.10f} ({prob_all_success * 100:.8f}%)")
    print(f"  • My conclusion: {1 / prob_all_success:.0f}-to-1 odds against successful fraud")

    # I will explain why this makes the protocol secure
    print(f"\nI observe that multiple rounds provide exponential security:")
    print(f"  • 1 round: 50% fraud success rate (insecure)")
    print(f"  • 10 rounds: 0.098% fraud success rate (acceptable)")
    print(f"  • 20 rounds: 0.0001% fraud success rate (highly secure)")


# I will now execute my Part 1 implementations to demonstrate the ZKP protocol
print("\n" + "=" * 70)
print("EXECUTING PART 1: My ZKP Protocol Simulations")
print("=" * 70)

# I will run the honest prover simulation first to establish the baseline
honest_success, honest_rate = simulate_zkp_honest(20)

# I will run the malicious prover simulation to show the security aspect
malicious_success, malicious_rate = simulate_zkp_malicious(20)

# I will perform the mathematical analysis to tie theory to practice
calculate_security_analysis(20)

print("\n" + "=" * 70)

# PART 2: CODE OBFUSCATION CHALLENGE
print("PART 2: Code Obfuscation Implementation Challenge")
print("-" * 55)

# To complete the obfuscation challenge, I will first create simple, readable functions
# that I can then obfuscate using different techniques
print("\n STEP 1: Creating Original Functions for Obfuscation")
print("-" * 55)


# I will implement a factorial function as my first test subject for obfuscation
# because it's simple enough to understand but complex enough to demonstrate obfuscation effects
def factorial_original(n):
    """
    I am implementing this factorial function with clear, descriptive names
    and straightforward logic to serve as the baseline for obfuscation comparison.
    """
    # I will validate input to handle edge cases properly
    if n < 0:
        return None  # I return None for invalid negative inputs

    # I will use an iterative approach for clarity
    result = 1  # I initialize the result to 1 (factorial identity)

    # I will multiply each number from 1 to n
    for i in range(1, n + 1):
        result *= i  # I accumulate the product in the result variable

    # I will return the final calculated factorial
    return result


# I will implement a Fibonacci function as my second obfuscation test case
# because it demonstrates iterative logic with multiple variables
def fibonacci_original(n):
    """
    I am implementing this Fibonacci function with descriptive variable names
    and clear logic flow to contrast with the obfuscated version later.
    """
    # I will handle the base cases first
    if n <= 0:
        return 0  # I return 0 for non-positive inputs
    elif n == 1:
        return 1  # I return 1 for the first Fibonacci number

    # I will use two variables to track the sequence iteratively
    prev = 0  # I store the previous Fibonacci number (F[n-2])
    current = 1  # I store the current Fibonacci number (F[n-1])

    # I will calculate each subsequent Fibonacci number
    for i in range(2, n + 1):
        temp = prev + current  # I calculate the next number in sequence
        prev = current  # I update the previous number
        current = temp  # I update the current number

    # I will return the nth Fibonacci number
    return current


# I will display the original code for comparison purposes
print("I have implemented these original functions with clear naming:")
print("\nOriginal Factorial Function (Readable):")
print("def factorial_original(n):")
print("    if n < 0:")
print("        return None")
print("    result = 1")
print("    for i in range(1, n + 1):")
print("        result *= i")
print("    return result")

print("\nOriginal Fibonacci Function (Readable):")
print("def fibonacci_original(n):")
print("    if n <= 0:")
print("        return 0")
print("    elif n == 1:")
print("        return 1")
print("    prev = 0")
print("    current = 1")
print("    for i in range(2, n + 1):")
print("        temp = prev + current")
print("        prev = current")
print("        current = temp")
print("    return current")

# I will now apply manual obfuscation techniques to make the code harder to understand
print("\n STEP 2: Applying Manual Obfuscation Techniques")
print("-" * 55)


# I will create an obfuscated version of the factorial function by renaming all identifiers
# to meaningless combinations of letters and numbers
def a1b2c3(x9z):
    """
    I am implementing the same factorial logic but with obfuscated names.
    This demonstrates how identifier renaming reduces code readability
    while maintaining identical functionality.
    """
    # I will use the same logic but with meaningless variable names
    if x9z < 0:
        return None  # I maintain the same input validation

    # I will rename 'result' to a meaningless identifier
    q7w = 1  # This was 'result' in the original version

    # I will rename the loop variable to something non-descriptive
    for m3n in range(1, x9z + 1):  # 'm3n' was 'i' in the original
        q7w *= m3n  # I perform the same multiplication with obfuscated names

    # I will return the same result with the obfuscated variable name
    return q7w


# I will create an obfuscated version of the Fibonacci function using similar techniques
def p8k4(y6t):
    """
    I am implementing the same Fibonacci logic but with obfuscated identifiers.
    This shows how name obfuscation affects code comprehension while preserving behavior.
    """
    # I will maintain the same base case logic with obfuscated parameter names
    if y6t <= 0:
        return 0  # I keep the same return values
    elif y6t == 1:
        return 1  # I maintain the same base case handling

    # I will rename all variables to meaningless identifiers
    r5v = 0  # This was 'prev' in the original version
    s2h = 1  # This was 'current' in the original version

    # I will use obfuscated names in the main calculation loop
    for d9f in range(2, y6t + 1):  # 'd9f' was 'i' in the original
        l1g = r5v + s2h  # 'l1g' was 'temp' in the original
        r5v = s2h  # I update using obfuscated variable names
        s2h = l1g  # I maintain the same algorithmic flow

    # I will return the result using the obfuscated variable name
    return s2h


# I will display the obfuscated code to show the transformation
print("I have applied manual obfuscation through identifier renaming:")
print("\nManually Obfuscated Factorial (Harder to Read):")
print("def a1b2c3(x9z):  # I renamed 'factorial_original' to 'a1b2c3'")
print("    if x9z < 0:   # I renamed parameter 'n' to 'x9z'")
print("        return None")
print("    q7w = 1       # I renamed 'result' to 'q7w'")
print("    for m3n in range(1, x9z + 1):  # I renamed 'i' to 'm3n'")
print("        q7w *= m3n")
print("    return q7w")

print("\nManually Obfuscated Fibonacci (Harder to Read):")
print("def p8k4(y6t):    # I renamed 'fibonacci_original' to 'p8k4'")
print("    if y6t <= 0:  # I renamed parameter 'n' to 'y6t'")
print("        return 0")
print("    elif y6t == 1:")
print("        return 1")
print("    r5v = 0       # I renamed 'prev' to 'r5v'")
print("    s2h = 1       # I renamed 'current' to 's2h'")
print("    for d9f in range(2, y6t + 1):  # I renamed 'i' to 'd9f'")
print("        l1g = r5v + s2h  # I renamed 'temp' to 'l1g'")
print("        r5v = s2h")
print("        s2h = l1g")
print("    return s2h")

# I will test both versions to verify they produce identical results
print("\n STEP 3: Testing Original vs Obfuscated Functions")
print("-" * 55)

# I will define test cases to verify that obfuscation doesn't break functionality
test_values = [5, 7, 10]

print("I will now verify that my obfuscated functions work identically:")
print("\nTesting Factorial Functions:")
# I will test each value with both versions to ensure correctness
for val in test_values:
    original_result = factorial_original(val)  # I calculate using the original function
    obfuscated_result = a1b2c3(val)  # I calculate using the obfuscated function
    match = original_result == obfuscated_result  # I verify they produce the same result
    print(
        f"  factorial({val}): Original={original_result}, Obfuscated={obfuscated_result}, Match={'✓' if match else '✗'}")

print("\nTesting Fibonacci Functions:")
# I will perform the same verification for Fibonacci functions
for val in test_values:
    original_result = fibonacci_original(val)  # I test the original implementation
    obfuscated_result = p8k4(val)  # I test the obfuscated implementation
    match = original_result == obfuscated_result  # I confirm identical behavior
    print(
        f"  fibonacci({val}): Original={original_result}, Obfuscated={obfuscated_result}, Match={'✓' if match else '✗'}")